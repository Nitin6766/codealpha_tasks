
import React, { useState, useEffect } from 'react';

const quotes = [
  { text: "Be yourself; everyone else is already taken.", author: "Oscar Wilde" },
  { text: "Two things are infinite: the universe and human stupidity; and I'm not sure about the universe.", author: "Albert Einstein" },
  { text: "So many books, so little time.", author: "Frank Zappa" },
  { text: "A room without books is like a body without a soul.", author: "Marcus Tullius Cicero" },
  { text: "You only live once, but if you do it right, once is enough.", author: "Mae West" },
];

export default function RandomQuoteGenerator() {
  const [quote, setQuote] = useState({ text: '', author: '' });

  const getRandomQuote = () => {
    const randomIndex = Math.floor(Math.random() * quotes.length);
    setQuote(quotes[randomIndex]);
  };

  const downloadQuote = () => {
    const fileContent = `"${quote.text}" — ${quote.author}`;
    const blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'quote.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
  };

  useEffect(() => {
    getRandomQuote();
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
      <div className="max-w-xl w-full bg-white text-center p-6 shadow-xl rounded-2xl">
        <p className="text-xl font-medium mb-4 text-gray-800">&ldquo;{quote.text}&rdquo;</p>
        <p className="text-sm text-gray-500 mb-6">— {quote.author}</p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={getRandomQuote}
            className="bg-blue-500 hover:bg-blue-600 text-white rounded-xl px-6 py-2"
          >
            New Quote
          </button>
          <button
            onClick={downloadQuote}
            className="bg-green-500 hover:bg-green-600 text-white rounded-xl px-6 py-2"
          >
            Download Quote
          </button>
        </div>
      </div>
    </div>
  );
}
